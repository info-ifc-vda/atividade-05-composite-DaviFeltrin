// Arquivo: SimpleTask.java
public class SimpleTask implements Task {
    private String title;
    private String description;
    private String deadline;

    public SimpleTask(String title, String description, String deadline) {
        this.title = title;
        this.description = description;
        this.deadline = deadline;
    }

@Override
public void display(String indent) {
// Usando as variáveis diretamente aqui para o console
System.out.println(indent + "[-] Tarefa: " + this.title + " | Prazo: " + this.deadline);
System.out.println(indent + "    Desc: " + this.description);
}

    @Override
    public String getTitle() {
        return title;
    }

    // Getters adicionais para evitar o alerta de "variável não utilizada"
    public String getDescription() { return description; }
    public String getDeadline() { return deadline; }
}