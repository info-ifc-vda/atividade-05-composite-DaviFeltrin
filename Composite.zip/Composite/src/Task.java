// Arquivo: Task.java
public interface Task {
    void display(String indent);
    String getTitle();
}
