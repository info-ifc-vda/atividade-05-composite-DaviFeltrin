// Arquivo: CompositeTask.java
import java.util.ArrayList;
import java.util.List;

public class CompositeTask implements Task {
    private String title;
    private List<Task> tasks = new ArrayList<>();

    public CompositeTask(String title) {
        this.title = title;
    }

    public void addTask(Task task) {
        this.tasks.add(task);
    }

    public void removeTask(Task task) {
        this.tasks.remove(task);
    }

    @Override
    public void display(String indent) {
        System.out.println(indent + "[+] Grupo: " + this.title);
        // O uso da variável 'tasks' aqui dentro deve sumir com o sublinhado amarelo
        for (Task t : this.tasks) {
            t.display(indent + "    ");
        }
    }

    @Override
    public String getTitle() {
        return title;
    }

    // Retorna a lista para que a IDE veja que ela é acessível
    public List<Task> getTasks() {
        return tasks;
    }
}