// Arquivo: IssueManager.java
public class IssueManager {
    public static void main(String[] args) {
        // 1. Criar tarefas simples
        SimpleTask t1 = new SimpleTask("Setup DB", "Instalar Postgres", "20/10");
        SimpleTask t2 = new SimpleTask("Login", "Criar tela de login", "22/10");
        
        // 2. Criar uma tarefa composta (um grupo)
        CompositeTask grupoDev = new CompositeTask("Desenvolvimento");
        grupoDev.addTask(t1);
        grupoDev.addTask(t2);
        
        // 3. Criar a raiz do projeto
        CompositeTask projetoPrincipal = new CompositeTask("Sistema ERP");
        projetoPrincipal.addTask(grupoDev);
        projetoPrincipal.addTask(new SimpleTask("Reunião", "Alinhamento com cliente", "25/10"));

        // 4. Exibir tudo
        projetoPrincipal.display("");
    }
}
