package swing;

import java.awt.BorderLayout;
import java.awt.FlowLayout;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JIssue;

public class Client {

	public static void main(String[] args) {

		JLabel title = new JLabel("Título da minha tarefa");
		JLabel label = new JLabel("Descrição da tarefa");
		JButton button= new JButton("OK");
				
		JIssue issue = new JIssue(new FlowLayout());
		issue.add(title);
		issue.add(label);  
		issue.add(button);  
		
		JFrame frame =new JFrame();  
		frame.setLayout(new BorderLayout());		
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setSize(400,200);  		          
		
		frame.add(title, BorderLayout.NORTH);
		frame.add(panel, BorderLayout.CENTER);
		
		frame.setVisible(true);
	}
}